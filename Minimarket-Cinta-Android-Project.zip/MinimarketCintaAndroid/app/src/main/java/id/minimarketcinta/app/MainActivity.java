package id.minimarketcinta.app;

import androidx.activity.ComponentActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.net.Uri;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.webkit.WebViewAssetLoader;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends ComponentActivity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private ActivityResultLauncher<Intent> filePicker;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(15,107,92));
        getWindow().setNavigationBarColor(android.graphics.Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(0);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        filePicker = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (fileCallback == null) return;
            Uri[] uris = null;
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                Uri data = result.getData().getData();
                if (data != null) uris = new Uri[]{data};
                else if (result.getData().getClipData() != null) {
                    int n = result.getData().getClipData().getItemCount(); uris = new Uri[n];
                    for (int i=0;i<n;i++) uris[i]=result.getData().getClipData().getItemAt(i).getUri();
                }
            }
            fileCallback.onReceiveValue(uris); fileCallback = null;
        });

        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClient() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });
        webView.addJavascriptInterface(new ScannerBridge(), "AndroidScanner");
        webView.addJavascriptInterface(new PrinterBridge(), "AndroidPrinter");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try { filePicker.launch(params.createIntent()); return true; }
                catch (Exception e) { fileCallback = null; Toast.makeText(MainActivity.this,"Pemilih file tidak tersedia",Toast.LENGTH_SHORT).show(); return false; }
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private class ScannerBridge {
        @JavascriptInterface public void scanBarcode() {
            runOnUiThread(() -> {
                IntentIntegrator integrator = new IntentIntegrator(MainActivity.this);
                integrator.setDesiredBarcodeFormats(IntentIntegrator.PRODUCT_CODE_TYPES);
                integrator.setPrompt("Arahkan kamera ke barcode produk");
                integrator.setBeepEnabled(false);
                integrator.setOrientationLocked(true);
                integrator.initiateScan();
            });
        }
    }
    private class PrinterBridge {
        @JavascriptInterface public void printReceipt(String receipt) {
            runOnUiThread(() -> {
                try {
                    PrintManager pm = (PrintManager)getSystemService(Context.PRINT_SERVICE);
                    android.webkit.WebView printView = new android.webkit.WebView(MainActivity.this);
                    printView.setWebViewClient(new WebViewClient() {
                        @Override public void onPageFinished(WebView view, String url) {
                            pm.print("Struk-Minimarket-Cinta", printView.createPrintDocumentAdapter("Struk Minimarket Cinta"), new PrintAttributes.Builder().build());
                        }
                    });
                    printView.loadDataWithBaseURL(null, "<html><meta charset='utf-8'><body style='font:12px monospace;white-space:pre-wrap'>" +
                        escapeHtml(receipt) + "</body></html>", "text/html", "UTF-8", null);
                } catch (Exception e) { Toast.makeText(MainActivity.this,"Cetak tidak tersedia di perangkat ini",Toast.LENGTH_LONG).show(); }
            });
        }
    }
    private String escapeHtml(String s) { return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;"); }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() != null) {
                String code = result.getContents().replace("\\", "\\\\").replace("'", "\\'");
                webView.evaluateJavascript("window.onCode('" + code + "')", null);
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
