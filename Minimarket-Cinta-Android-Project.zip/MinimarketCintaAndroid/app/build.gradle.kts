plugins { id("com.android.application") }

android {
    namespace = "id.minimarketcinta.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.minimarketcinta.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}

dependencies {
    implementation("androidx.activity:activity:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
}
